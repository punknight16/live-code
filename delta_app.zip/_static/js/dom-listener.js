function domListener(e){
	AppContext.caret_topnode = e.currentTarget;
}